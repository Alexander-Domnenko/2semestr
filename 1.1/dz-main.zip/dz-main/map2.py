a1=[12,2,3]
a2=[1,2,3]
a3=[3,3,2]
s=[]
for a, b, c in zip(a1, a2, a3):
    s.append(a * b * c)
print(s)  
