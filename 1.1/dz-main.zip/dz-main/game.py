import pygame
import os
import random
from pygame.locals import (
K_w,
K_s,
K_a,
K_d,
K_SPACE,
K_ESCAPE,
KEYDOWN,
QUIT,
RLEACCEL
)
vragspeed=2
pygame.init()
win= pygame.display.set_mode((700,660))
pygame.display.set_caption("gaaaaaaaaaaaaaaaaaaaaaaame")
run=True
bg_color=(0,0,0)


def stolknovenie():
    global run
    if pygame.sprite.spritecollideany(player,enemies):
        run=False

vrag=pygame.sprite.Sprite()
vrag2=pygame.sprite.Sprite()
vrag3=pygame.sprite.Sprite()


def vrag2Init():

    global vrag2
    vrag2.image=pygame.image.load('pixil-frame-2.png').convert()
    vrag2.image.set_colorkey((0,0,0),RLEACCEL)
    vrag2.rect=vrag2.image.get_rect(center=(random.randint(0,700),random.randint(-40,0)))

def vrag2Update():
    global vrag2

    if vrag2.rect.top<700:
        vrag2.rect.move_ip(0, 1)
    if vrag2.rect.top>600:
        vrag2.rect=vrag2.image.get_rect(center=(random.randint(0,700),random.randint(-540,-400)))
vrag3=pygame.sprite.Sprite()

def vrag3Init():

    global vrag3
    vrag3.image=pygame.image.load('pixil-frame-2.png').convert()
    vrag3.image.set_colorkey((0,0,0),RLEACCEL)
    vrag3.rect=vrag3.image.get_rect(center=(random.randint(0,700),random.randint(-1100,-1000)))

def vrag3Update():
    global vrag3
    global vragspeed
    if vrag3.rect.top<700:
        vrag3.rect.move_ip(0, 3)
    if vrag3.rect.top>600:
        vrag3.rect=vrag3.image.get_rect(center=(random.randint(0,700),random.randint(-540,-400)))
player=pygame.sprite.Sprite()


def vragInit():
 
    global vrag
    vrag.image=pygame.image.load('pixil-frame-2.png').convert()
    vrag.image.set_colorkey((0,0,0),RLEACCEL)
    vrag.rect=vrag.image.get_rect(center=(random.randint(0,700),random.randint(-40,0)))

def vragUpdate():
    global vrag

    if vrag.rect.top<700:
        vrag.rect.move_ip(0, 2)
    if vrag.rect.top>600:
        vrag.rect=vrag.image.get_rect(center=(random.randint(0,700),random.randint(-40,0)))

def playerInit():
    global player
    player.image=pygame.image.load('pixil-frame-0.png').convert()
    player.image.set_colorkey((0,0,0),RLEACCEL)
    player.rect=player.image.get_rect(center=(350,600))
    
    
def playerUpdate(pressed_keys):
    global player
    if pressed_keys[K_w]and player.rect.top>430:
        player.rect.move_ip(0, -2)
    if pressed_keys[K_s] and player.rect.bottom<650:
        player.rect.move_ip(0, 2)
    if pressed_keys[K_a]and player.rect.left>0:
        player.rect.move_ip(-2, 0)
    if pressed_keys[K_d] and player.rect.right<700:
        player.rect.move_ip(2, 0)

playerInit()
vragInit()
vrag2Init()
vrag3Init()
#gunshot()

enemies=pygame.sprite.Group([vrag,vrag2,vrag3])

en=pygame.sprite.Group()
en.add(player)

while run:
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run= False
    
    
    pressed_keys = pygame.key.get_pressed()
    playerUpdate(pressed_keys)
    #shotgunUpdate()
    #shotUpdate()
    stolknovenie()
    win.fill(bg_color)
    vragUpdate()
    vrag2Update()
    vrag3Update()
    win.blit(player.image, player.rect)
    win.blit(vrag.image, vrag.rect)
    win.blit(vrag2.image, vrag2.rect)
    win.blit(vrag3.image, vrag2.rect)
    #win.blit(gun.image,gun.rect)
    
    pygame.display.flip()
pygame.quit()
