for number1 in range(1,10):
    if number1 == number1**1:
        print(number1)
for number2 in range (10, 100):
	if number2 == (number2//10)**2 +(number2%10)**2:
		print(number2)
for number3 in range (100, 1000):
	if number3 == (number3 // 100)**3+(number3 %100//10)**3 +(number3%10)**3:
		print(number3) 
for number4 in range (1000, 10000):
	if number4 ==(number4//1000)**4+(number4 // 100%10)**4+(number4 %100//10)**4 +(number4%10)**4:
		print(number4)

		

