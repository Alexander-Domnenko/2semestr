k = 0
file = open('1.txt', encoding='utf-8')
question_prompts = file.readlines()

questions = [
    (question_prompts[0], "a"),
    (question_prompts[1], "b"),
    (question_prompts[2], "c")

]
otvet = ['a', 'b', 'c']

import tkinter as tk


def get_entry_1():
    value = name1.get()
    if value == otvet[0]:
        print(value)
        global k
        k += 1
    else:
        print('empty')


def get_entry_2():
    value = name2.get()
    if value == otvet[1]:
        print(value)
        global k
        k += 1
    else:
        print('empty')


def get_entry_3():
    value = name3.get()
    if value == otvet[2]:
        print(value)
        global k
        k += 1
    else:
        print('empty')

def get_entry_4():
    value = name4.get()
    if value == otvet[1]:
        print(value)
        global k
        k += 1
    else:
        print('empty')
def get_entry_5():
    value = name5.get()
    if value == 'ac':
        print(value)
        global k
        k += 1
    else:
        print('empty')
def kolvo():
    value = name4.get()
    global k
    print(k)
    label = tk.Label(win, text=k).grid(row=5, column=1, stick='w')


win = tk.Tk()
win.geometry(f"900x700+100+200")

tk.Label(win, text=question_prompts[0]).grid(row=0, column=0, stick='w')
name1 = tk.Entry(win)
name1.grid(row=0, column=1)
tk.Button(win, text='get', command=get_entry_1).grid(row=0, column=2)

tk.Label(win, text=question_prompts[1]).grid(row=1, column=0, stick='w')
name2 = tk.Entry(win)
name2.grid(row=1, column=1)
tk.Button(win, text='get', command=get_entry_2).grid(row=1, column=2)

tk.Label(win, text=question_prompts[2]).grid(row=2, column=0, stick='w')
name3 = tk.Entry(win)
name3.grid(row=2, column=1)
tk.Button(win, text='get', command=get_entry_3).grid(row=2, column=2)

tk.Label(win, text=question_prompts[3]).grid(row=3, column=0, stick='w')
name4 = tk.Entry(win)
name4.grid(row=3, column=1)
tk.Button(win, text='get', command=get_entry_4).grid(row=3, column=2)

tk.Label(win, text=question_prompts[4]).grid(row=4, column=0, stick='w')
name5 = tk.Entry(win)
name5.grid(row=4, column=1)
tk.Button(win, text='get', command=get_entry_5).grid(row=4, column=2)

tk.Label(win, text='колв-правильных').grid(row=5, column=0, stick='w')
tk.Button(win, text='get', command=kolvo).grid(row=5, column=2, stick='w')

win.grid_columnconfigure(0, minsize=100)
win.grid_columnconfigure(1, minsize=100)
win.mainloop()

