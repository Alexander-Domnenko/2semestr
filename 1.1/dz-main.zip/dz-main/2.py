for num1 in range(1,10001):
    del_1=[i for i in range(1,num1//2+1)if num1%i == 0]
    num2 = sum(del_1)
    del_2=[i for i in range(1,num2//2+1)if num2%i ==0]
    if num1 ==sum(del_2)and num2 ==sum(del_1) and (num2>num1):
            print(num1,num2)

            
