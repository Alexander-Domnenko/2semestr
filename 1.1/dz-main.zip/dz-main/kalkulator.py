try:
    num1=int(input('Введите первое число: '))
    num2=int(input('Введите второе чсло: '))
    deystvie=input('Введите действие:"+" или "-" или "*" или "/" ')
    if deystvie=='+':
        print(num1+num2)
    elif deystvie=='-':
        print(num1-num2)
    elif deystvie=='*':
        print(num1*num2)
    elif deystvie=='/':
        print(num1/num2)
    else:
        print('неккоректное действие')
except ValueError:
    print('Проверьте корректность числа и запустите программу снова')
except ZeroDivisionError:
    print("На ноль делить нельзя")


    
