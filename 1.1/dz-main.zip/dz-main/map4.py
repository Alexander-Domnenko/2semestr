a=[(1, 2, 3), (1, 2) ,1, ('a', 'a', 'a', 6), ()]
b=list(filter(lambda x: a.index(x) % 2 == 0, a))
print(b)
