import tkinter as tk
from tkinter import END


def summa():
    a = vvod_second.get()
    b = second.get()
    try:
        a, b = float(a), float(b)
        Result.delete(0, END)
        Result.insert(0, a + b)
    except ValueError:
        Result.delete(0, END)
        Result.insert(0, "Неккорктный ввод, попробуйте снова")





win = tk.Tk()
win.geometry('600x500')
win['bg'] = 'pink'
win.title('Сложение двух чисел')
text=tk.Label(win,text='Введите первое число',
                
                font=('Calibri',14),
                width=25,
               
                
                )
text.pack()
vvod_second = tk.Entry(win, 
                bg='red',
                fg='blue',
                font=('Calibri',20),
                width=30,
                relief=tk.RAISED,bd=5,
                
                )

vvod_second.pack()
text2=tk.Label(win,text='Введите второе число', font=('Calibri',14),
                width=25,
               )
text2.pack()
second = tk.Entry(win, 
                bg='red',
                fg='blue',
                font=('Calibri',20),
                width=30,
                relief=tk.RAISED,bd=5
                )

second.pack()

text3=tk.Label(win,text='Выберите действие', font=('Calibri',14),
                width=25,
               )
text3.pack()
buton=tk.Button(win,text='+',command=summa,width=4,height=1,bg='red',font=('Calibri',18),activebackground='blue',relief=tk.RAISED,bd=5,)
buton.pack()
text4=tk.Label(win,text='Результат', font=('Calibri',14),
                width=25,
               )
text4.pack()
Result = tk.Entry(win,
                bg='red',
                fg='blue',
                font=('Calibri',18),
                width=35,
                relief=tk.RAISED,bd=5,
                
                )
Result.pack()
win.mainloop()
 
