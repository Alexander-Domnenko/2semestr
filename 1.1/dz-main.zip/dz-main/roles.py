d={}
dd={'Слова автора':[]}
osnovas=[]
avtor=[]
c=0
file= open('roles.txt', encoding='utf-8') 
file=file.read()
#file=file.replace(')','')
file=file.split('textLines:')

text=file[1]
#print(text)
roles=file[0].split('\n')
roles=roles[1:-1]
#print(roles)
for rol in roles:
    text = text.replace(f'{rol}:', f'>>>{rol}:')
    #print(text)
osnova = text.split('>>>')
#print(text)
osnovaa=file[1].replace(')','')
osnovaa=osnovaa.split('\n')
osnovaa=osnovaa[1:]
#print(osnovaa)



for i in roles:
    d.setdefault(i,[])

for j in range(len(roles)):
    for i in osnova:
        osnovas=i.split(':')
        if  osnovas[0]==roles[j]:
            d[roles[j]].append(osnovas[1:])
      
for i in osnovaa:
    if '(' in i:
        avtor.append(i)
        #print(avtor)
for i in avtor:
    if '(' in i:
        avtor=i.split(' (')
        #print(avtor)
        dd['Слова автора'].append(avtor[-1])


for i in d:
    text=d[i]
    print(f'{i}:')
    #print(*text)
    print('\n'.join(map(', '.join, text)))
    
for i in dd:
    textt=dd[i]
    print(f'{i}:')
    print(*textt,sep='\n')
