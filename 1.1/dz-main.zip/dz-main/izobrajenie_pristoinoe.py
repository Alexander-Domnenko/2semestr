import turtle
window= turtle.Screen()
window.title("Hello Turtle")
turtle.shape("turtle")
joe=turtle.Turtle()
joe.speed(0)
joe.screen.clear()#вроде без черепашки крисивее
for i in range(10):
    for colors in ['red','green','blue','cyan']:
        joe.color(colors)
        joe.circle(100)
        joe.left(10)

joe.hideturtle()
window.exitonclick()
