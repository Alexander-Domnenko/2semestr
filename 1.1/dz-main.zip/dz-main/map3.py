a=[(2,2,4,5,4),2,(3,4),()]
g=list(map(lambda x: len(str(x).replace(' ', '').replace(')', '').replace('(', '').replace(',', '').replace("'", '')), a))
print(g)
