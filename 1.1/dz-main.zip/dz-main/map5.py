a=[(1, 2, 3), (1, 2), (1, 1, 1), 1, ('a', 'a', 'a', 6), ()]
b=filter(lambda x:x!=(),a)
print(list(b))
