try:
    filename=input('Введите полное имя файла: ')
    with open(filename, 'r') as file:
        a = file.readlines()
    del a[0]
    a = [[int(n)for n in x.split()] for x in a]
    print('Изначальный массив: ')
    print(a)
    for g in a:
        b=g
        for k in range(len(b)-1):
            for kk in range(len(b)-1):
                if int(b[kk])>int(b[kk+1]):
                    b[kk],b[kk+1]=b[kk+1],b[kk]
    for i in range(len(a)-1):
        for j in range(len(a)-1):
            if a[j]>a[j+1]:
                a[j],a[j+1]=a[j+1],a[j]
    print('Результат сортировки: ')
    print(a)
except FileNotFoundError:
    print('Файл не найден. Проверьте имя файла(оно должно быть с расширением.txt)')
    exit()
except ValueError:
    print('В считываевом файле ошибка, проверьте исходный файл')
    exit()
