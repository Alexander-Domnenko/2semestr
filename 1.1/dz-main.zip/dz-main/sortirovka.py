import os.path
try:
    filename=input("Введите полное имя файла: ")
    filename2=input("Введите полное имя выводимого файла: ")
    if os.path.exists(filename2) == True:
        print("Файл записи уже существует, вы точно хотите перезаписать его?")
        prod=input("Нажмите Enter, если хотите продолжить, n чтобы отказаться")
        if prod=="n":
            exit()
    if filename == filename2:
        print("Файл записи уже существует, вы точно хотите перезаписать его?")
        prod=input("Нажмите Enter, если хотите продолжить, n чтобы отказаться")
        if prod=="n":
            exit()
    with open(filename, 'r+') as file:
        m=""
        s=file.read().replace('\n',' ')
        m=s.split(' ')
        n=len(m)  
        for run in range(n-1):
            for i in range(n-1-run):
                if int(m[i])>int(m[i+1]):
                    m[i],m[i+1]=m[i+1],m[i]
    with open(filename2,'w') as file1:
        for el in m:
            file1.write(str(el)+'\n')
except FileNotFoundError:
    print("Файл не найден")
    exit()
except ValueError:
    print("Ошибка в файле")
    exit()
print(*m)
print("Домненко Александр 14122")
print()
print("Изначально мы считываем файл и переводим запись из столбика в строчный вид,затем сортируем методом 'пузырек' числа в файле")
print()
print("пузырек- сравнивает число справа и ставит большее вправо, меньшее влево")
