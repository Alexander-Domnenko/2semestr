a=[1,2,3]
b=[3,2,3]
g1=list(map(lambda x:x*2,a))
g2=list(map(lambda x:x*2,b))
c=list(zip(g1,g2))
print(c)
