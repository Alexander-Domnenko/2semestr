a=[1,2,3]
b=[3,2,3]
c=['a','a','a']
print(list(zip(a, b, c)))
